import java.util.Scanner;
class AssgnQue7{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter marks obtained :");
int a1=sc.nextInt();
int b1=sc.nextInt();
int c1=sc.nextInt();
int d1=sc.nextInt();
int e1=sc.nextInt();

int a=100;
int b=100;
int c=100;
int d=100;
int e=100;

int tot1=a+b+c+d+e;
int tot2=a1+b1+c1+d1+e1;
//System.out.println("Total marks="+tot1);
//System.out.println("Total marks obtained="+tot2);

double per=tot2*100/tot1;
System.out.println("percentage marks = "+per+"%");


}


}