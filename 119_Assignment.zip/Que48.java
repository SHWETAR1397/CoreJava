import java.util.*;

abstract class Processor{
	int data=1;
	/*
	public Process(){
		data=1;
	}
	
	public Processor(int data){
		super();
		this.data=data;
	}
	*/
	
	abstract void process();
	void showData(){
		System.out.println("Data : "+data);
	}
}
class Factorial extends Processor{
	void process(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value");
		int n1=sc.nextInt();
		
		for(int i=1;i<=n1;i++){
		data=data*i;
		}
		
		
		
		
			
	}
}
class Circle extends Processor{
	void process(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value");
		int n2=sc.nextInt();
		data=(int)3.14*n2*n2;
		//System.out.println("Area="+data);
		
	}
}
public class Que48{
	public static void main(String srgs[]){
		
		System.out.println("Enter the choice");
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();
		Processor p1=new Factorial();
		Processor p2=new Circle();
		if(ch==1){
			p1.process();
			p1.showData();
			
		}
		if(ch==2){
			p2.process();
			p2.showData();
			
		}
		 
	}
	
}









