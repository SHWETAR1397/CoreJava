import java.util.Scanner;
class AssgnQue18{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the number:");
int num=sc.nextInt();
int remainder;
  boolean isPrime=true;        
  
  for(int i=2;i<=num/2;i++)
  {
               remainder=num%i;
           
            
           if(remainder==0)
     {
        isPrime=false;
        break;
     }
  }
  if(isPrime){
     System.out.println(num + " is a Prime number");
  }else{
     System.out.println(num + " is not a Prime number");
}
    }
  }

