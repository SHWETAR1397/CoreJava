import java.util.*;

interface Taxable{             
	int salaryTax=7;
	double incomeTax=10.5;         //public static final
	
	void calcTax();
}

class Employee implements Taxable{
	int empId;
	String name;
	double salary;
	
	Employee(){};
	
    Employee(int empId,String name,double salary){
		this.empId=empId;
		this.name=name;
		this.salary=salary;
}
	
	public void calcTax(){
		 double totalTaxSal=salary*salaryTax*12;
		 System.out.println("total tax : "+totalTaxSal);
	}
	/*
	void show(){
		System.out.println("id :"+empId+" name :"+name+" tax : "+totalTax);
	}
	*/
}

public class Que49{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter salary");
		double sal=sc.nextDouble();
		
		Employee e=new Employee(id,name,sal);
		e.calcTax();

		
		
	}
} 
