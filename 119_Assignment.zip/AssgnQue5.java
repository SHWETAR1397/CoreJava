import java.util.Scanner;
class AssgnQue5 {
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter user name");
String nm=sc.next();
System.out.println("Welcome "+nm);
}
}