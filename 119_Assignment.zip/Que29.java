import java.util.Scanner;
class Que29 {
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter row and column");
int r=sc.nextInt();
int c=sc.nextInt();
int arr[][]=new int[r][c];
 for(int i=0;i<arr.length;i++){
for(int j=0;j<arr[i].length;j++){
System.out.println("Enter array elements");
arr[i][j]=sc.nextInt();
}
}
for(int ar[]:arr){
for(int a:ar){
System.out.print(" "+a);
}
System.out.println("");
}
//to print no of rows    ==== count=arr.length;
int count=0;
for(int i=0;i<arr.length;i++){
for(int j=0;j<arr[i].length;j++){
}
count=count+1;
}
System.out.println("Total no of 1D arrays in a 2D array = "+count);

//to print no of columns
count=arr[0].length;
System.out.println("Number of elements in every one-D array  = "+count);
}
}


