import java.util.Scanner;
class Product{
	int pid;
	double price;
	int qty;
	public Product(){
		int pid=0;
		double price=0;
		int qty=0;
	}
	Product(int pid,double price,int qty){
		this.pid=pid;
		this.price=price;
		this.qty=qty;
	}
	void display(){
		System.out.println("Pid : "+this.pid+" Price : "+this.price+" Quantity : "+this.qty);
	}
	public static double calAmt(Product arr[]){
		double total=0;
		for(int i=0;i<arr.length;i++){
		double prodAmt=arr[i].price + arr[i].qty;
			total+=prodAmt;
		}
		return total;
		
	}
	
	
}
public class Que39{
public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	Product arr[]=new Product[5];
	
	for(int i=0;i<arr.length;i++){
		System.out.println("Enter pid, price and quantity ");
		int id=sc.nextInt();
		double price=sc.nextDouble();
		int qty=sc.nextInt();
		
		Product item=new Product(id,price,qty);
		arr[i]=item;
	}
	double max=0;
	int id=arr[0].pid;
	int qty=arr[0].qty;
	for(int i=0;i<5;i++){
		if(max<arr[i].price){
			max=arr[i].price;
			id=arr[i].pid;
			qty=arr[i].qty;
		}
	}
	System.out.println("Highest price Product :\n Pid : "+id+", Price : "+max+", quantity : "+qty);
	    System.out.println("Total Amount Spent : "+Product.calAmt(arr));
	
}
}
















