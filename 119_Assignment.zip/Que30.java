import java.util.Scanner;
class Que30 {
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
int arr[][]=new int[3][3];

for(int i=0;i<arr.length;i++){
for(int j=0;j<arr[i].length;j++){
System.out.println("Enter array elements");
arr[i][j]=sc.nextInt();
}
}
for(int ar[]:arr){
for(int a:ar){
System.out.print(" "+a);
}
System.out.println("");
}
int sum=0;
for(int i=0;i<arr.length;i++){
for(int j=0;j<arr[i].length;j++){
if(i==j){
sum=sum+arr[i][j];
}
}
}
System.out.println("sum of diagonal elements = "+sum);
}
}


