import java.util.Scanner;
class AssgnQue19a{

public static void main(String args[]){
int[] scores=new int[10];
scores=new int[3];
scores=new int[]{215,234,218,189,221,290};
for(int score:scores){
System.out.print(score+"");
}

}

  
  }

