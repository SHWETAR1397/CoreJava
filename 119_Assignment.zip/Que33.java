class Student{
	private int rno;
	private String name;
	void getData(int rno,String name){
	this.rno=rno;
	this.name=name;
	}
	void showData(){
	System.out.println("Roll no = "+rno);
	System.out.println("Name = "+name);
	}	

}
class Que33{
public static void main(String args[]){
	Student s[]={new Student(),new Student()};
	//s.getData(119,"Shweta");
	//s.showData();
	System.out.println("no of student objects = "+s.length);
}
}
