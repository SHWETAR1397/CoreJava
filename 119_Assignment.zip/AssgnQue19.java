import java.util.Scanner;
class AssgnQue19{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the number:");
int num=sc.nextInt();
int n=2;
for(int i=0; i<=num; i++){
{
n=n+10;
if(i==(num-1)){
System.out.print(n);
break;
}
System.out.print(n+"+");
}
}
}
}