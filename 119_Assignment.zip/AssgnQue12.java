import java.util.Scanner;
class AssgnQue12{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter basic salary :");
double s=sc.nextDouble();

if(s<10000){
	double hra=(10/100)*s;
	double da=(90/100)*s;
	double gs=s+da+hra;
	System.out.println("Gross Salary is :"+gs);
}else if(s>=10000){
	double hra=2000;
	double da=(98/100)*s;
	double gs=s+hra;
	System.out.println("Gross Salary is :"+gs);
	}
}
}