import java.util.*;

class Faculty{
	int id;
	double sal;
	void input(){
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter id no");
		this.id=sc.nextInt();
	}
	
	void PrintSal(){
		System.out.println("Salary = "+this.sal);
	}
}
class FullTime extends Faculty{
	double basicSal;
	double allowance;
	
	void input(){
		super.input();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter basic salary");
		this.basicSal=sc.nextDouble();
		System.out.println("Enter allowance");
		this.allowance=sc.nextDouble();
		
		super.sal=this.basicSal+this.allowance;
		PrintSal();
		//System.out.println("Salary = "+sal);
	}
	
}
class PartTime extends FullTime{
	double workingHours;
	double rateperHour;
	void input(){
		super.input();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter working hours");
		this.workingHours=sc.nextDouble();
		System.out.println("Enter Rate per hour");
		this.rateperHour=sc.nextDouble();
		
		super.sal=this.workingHours*this.rateperHour;
		PrintSal();
		//System.out.println("Salary = "+sal);
	}
	
}


public class Que44{
	public static void main(String args[]){
		PartTime pt=new PartTime();
		pt.input();
		
	}
}