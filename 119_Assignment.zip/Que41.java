import java.util.*;
class Person{
	String name;
	int age;
	Person(){
		this("Shweta",23);
		System.out.println("this is default const");
	}
Person(String name,int age){
	System.out.println("this is param const");
	this.name=name;
	this.age=age;
	
}
public void display(){
	System.out.println("Name = "+this.name+" Age = "+this.age);
}
}
public class Que41{
	public static void main(String args[]){
		
		Person p=new Person();
		p.display();
	}
}