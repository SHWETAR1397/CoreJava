import java.util.Scanner;
class MathOperation{
	static int add(int a,int b){
		return a+b;
	}
	static int subtract(int a,int b){
		return a-b;
	}
	static int multiply(int a, int b){
		return a*b;
	}
	static int power(int a,int b){
		int pow=1;
		for(int i=0;i<b;i++)
			pow=pow*a;
		return pow;
	}
}
class Que35{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two numbers");
		int a1=sc.nextInt();
		int b1=sc.nextInt();
		System.out.println(MathOperation.add(a1,b1));
		System.out.println(MathOperation.subtract(a1,b1));
		System.out.println(MathOperation.multiply(a1,b1));
		System.out.println(MathOperation.power(a1,b1));
	}
}