import java.util.Scanner;
class AssgnQue6{
public static void main(String arg[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter the radius");

Double r=sc.nextDouble();
System.out.println("Radius =" +r);

double a=(3.14*r*r);
System.out.println("Area =" +a);

double p=(2*3.14*r);
System.out.println("Perimeter =" +p);

}

}