import java.util.*;

class MathOpe{
	static int multiply(int a,int b){
		return a*b;
	}
	static float multiply(float a,float b,float c){
		return a*b*c;
	}
	
	static double multiply(int a,double b){
		return a*b;
	}
	static int multiply(int arr[]){
		int prod=1;
	for(int i=0;i<arr.length;i++){
		prod*=arr[i];
	}
	return prod;
	}
}
public class Que36{
	public static void main(String args[]){
		int arr[]=new int[]{1,2,4,6};
		System.out.println(MathOpe.multiply(10,20));
		System.out.println(MathOpe.multiply(10.5f,20.5f,20.5f));
		System.out.println(MathOpe.multiply(10,20.5));
		System.out.println(MathOpe.multiply(arr));
	}
}