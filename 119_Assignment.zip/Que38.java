import java.util.*;
class Employee{
	int empno;
	static double salary;
	double totSal;
	static int count;
	Employee(double salary){
		this.salary=salary;
		this.empno++;
		this.totSal+=salary;
		count++;
	}
	void show(){
		 System.out.println("Total Employees = "+count+" "+"Total Salary = "+totSal);
	}
}
public class Que38{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		Employee e = new Employee(50000.00);
	    Employee e1 = new Employee(50000.00);
	    Employee e2 = new Employee(50000.00);
	    Employee e3 = new Employee(50000.00);
	    Employee e4 = new Employee(50000.00);
	    Employee e5 = new Employee(50000.00);
	    e.show();
	} 
}