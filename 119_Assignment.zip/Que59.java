import java.util.Scanner;
class Voterage extends Throwable{
	int voterId;
	String name;
	int age;
	
	Voterage(){
		super("invalid age");
	}
	
	Voterage(int voterId, String name, int age) {
		this.voterId=voterId;
		this.name=name;
		this.age=age;
		
	}
}
class Que59{
	static void ageV(int Vage) throws Voterage{
		if(Vage>18){
			System.out.println("Age = "+Vage);
		}else {
			throw new Voterage();
		}
	}
	public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your age");
	int a=sc.nextInt();
	try{
		ageV(a);
	}catch(Voterage e){
	System.out.println(e);
	}
}
}