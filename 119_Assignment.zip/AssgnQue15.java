import java.util.Scanner;
class AssgnQue15{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the Gender:");
char m=sc.next().charAt(0);
char f=sc.next().charAt(0);

System.out.println("Enter the age of male:");
int ma=sc.nextInt();
System.out.println("Enter the age of female:");
int fa=sc.nextInt();

if((fa>=18 && ma>=21)){
System.out.println("Eligible");
}
else{
System.out.println("Not Eligible");
}
} 
}
