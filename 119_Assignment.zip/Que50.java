import java.util.*;

class Employee{
	String id;
	String name;
	double sal;
	
	Employee(){};
	
Employee(String id,String name,double sal){
	this.id=new String(id);
	this.name=name;
	this.sal=sal;
}
	public String toString(){
		return id+" "+name+" "+sal;
	}
}
public class Que50{
	public static void main(String args[]){
		Employee e[]=new Employee[5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++){
			int flag=0;
			
			System.out.println("Enter id");
			String empid=sc.next();
		for(int j=0;j<i;j++){
			if(e[j].id.equals(empid)){
				System.out.println("id already exist");
				i--;
				flag=1;
				break;
			}
		}
		if(flag==1)
			continue;
		
			System.out.println("Enter name");
			String name=sc.next();
			System.out.println("Enter salary");
			double sal=sc.nextDouble();
			Employee temp=new Employee(empid,name,sal);
			e[i]=temp;
		}
		for(Employee emp:e ){
			System.out.println(emp);
		}
		
		
		
		
	}
}