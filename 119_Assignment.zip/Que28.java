class Que28{
public static void main(String args[]){
String name[]=new String[]{"shweta","sejal","trisha","tani","nikita"};
for(String str:name){
System.out.print(str+" ");
}	
}
}



