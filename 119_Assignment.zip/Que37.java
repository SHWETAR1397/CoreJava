import java.util.*;
class Person{
	int age;
	String name;
	
	Person(){
		this.age=18;
	}
	
	Person(int age,String name){
		this.age=age;
		this.name=name;
	}
	
	void show(){
		System.out.println("Name = "+this.name);
		System.out.println("Age = "+this.age);
	}
	
}
public class Que37{
	public static void main(String args[]){
		Person p1=new Person();
		Person p2=new Person(23,"Shweta");
		p1.show();
		p2.show();
	}
}