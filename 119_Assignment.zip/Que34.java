import java.util.Scanner;
class Circle{
	double radius;
	double area;
	
	void init(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius");
		this.radius=sc.nextDouble();
	}
	void calculateArea(){
		this.area=3.14*this.radius*this.radius;
	}
	void display(){
		System.out.println("Radius = "+this.radius);
		System.out.println("Area = "+this.area);
	}
}
public class Que34{
	public static void main(String args[]){
		Circle c=new Circle();
		c.init();
		c.calculateArea();
		c.display();
	}
}