import java.util.*;

public class Que52{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the line");
		String text=sc.nextLine();
		
		int count=0;
		text=text.toLowerCase();
		for(int i=0;i<text.length();i++){
			char ch=text.charAt(i);
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u'){
				count++;
			}
		}
		System.out.println("Entered sample text : "+text);
		System.out.println("total no of vowels : "+count);
	}
}