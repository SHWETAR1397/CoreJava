import java.util.Scanner;
class Que23{
public static void main(String args[]){
       
Scanner s = new Scanner(System.in);
System.out.print("Enter no. of elements you want in array:");
int n = s.nextInt();
int arr[] = new int[n];

System.out.println("Enter array elements");
for(int i=0;i<arr.length;i++){
arr[i]=s.nextInt();
}
for(int a:arr){ 
System.out.print(" "+a);
}
System.out.println("\nArray in Reverse order");
for(int i=arr.length-1;i>=0;i--){
System.out.print(arr[i]+" ");
}    
}
}
