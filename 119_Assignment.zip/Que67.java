

import java.io.*;

public class Que67{

	public static void main(String[] args) {
		try {
			FileInputStream is = new FileInputStream("D://setup//Assign1.txt");
			ObjectInputStream ois = new ObjectInputStream(is);
			Que67 emp = (Que67) ois.readObject();
			ois.close();
			is.close();
			System.out.println(emp.toString());
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}
