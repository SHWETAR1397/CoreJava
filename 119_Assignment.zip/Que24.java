import java.util.Scanner;
class Que24{
public static void main(String args[]){
//int flag=0;
Scanner s = new Scanner(System.in);
System.out.print("Enter no. of elements you want in array:");
int n = s.nextInt();
int flag=s.nextInt();
flag=0;
int arr[] = new int[n];

System.out.println("Enter array elements");
for(int i=0;i<arr.length;i++){
arr[i]=s.nextInt();
} 
for(int a:arr){ 
System.out.print(" "+a);
}
System.out.println("\nEnter element to be search");
int ele= s.nextInt();

for(int i=0;i<arr.length;i++){
if(arr[i] == ele){
flag=1;
break;
}else{
flag=0;
}
}
if(flag==1){
System.out.println("element found");
}
else{
System.out.println("element not found");
}
}
}

