import java.util.*;

class Que56{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sc.nextLine();
		
		String arr[]=str.split(" ");
		String s="";
		for(int i=0;i<arr.length;i++){
			char ch=arr[i].charAt(0);
			ch=Character.toUpperCase(ch);
			if(i==arr.length-1)
				//System.out.println(ch+arr[i].substring(1));
			s = s+ch+arr[i].substring(1);
			else
			s = s+ch+arr[i].substring(1)+" ";
		}
		System.out.println(s);
	}
	
}