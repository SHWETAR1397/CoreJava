import java.util.Scanner;
class AssgnQue10{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter temperature in Fahrenheit:");
int f=sc.nextInt();

double c=5*(f-32)/9;
System.out.println("Temperature in Celsius: "+c);
}
}