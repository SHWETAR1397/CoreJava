class AssgnQue2{
public static void main(String arr[]){
int rollno=100;
System.out.println("roll no = "+rollno);

}
}