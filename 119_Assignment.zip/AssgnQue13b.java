import java.util.Scanner;
class AssgnQue13b{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the numbers :");
int a=sc.nextInt();
int b=sc.nextInt();
int c=sc.nextInt();

String s =(a > b && b > c)? "a is greater": b>c? "b is greater" : "c is greater";
System.out.println(s);
} 
}
