import java.util.Scanner;
class AssgnQue8{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter Principle :");
int p=sc.nextInt();
System.out.println("Enter Rate :");
int r=sc.nextInt();
System.out.println("Enter Time period :");
int t=sc.nextInt();

double si=(p*r*t)/100;
System.out.println("Simple Interest="+si);
}
}