import java.util.Scanner;
class AssgnQue9{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter no of days:");
int n=sc.nextInt();

int y=n/365;
System.out.println("No of years="+y);

int a=n%365;
int m=a/30;
System.out.println("No of months="+m);

int b=a%30;
int w=b/7;
System.out.println("No of weeks="+w);

int d=b%7;
System.out.println("No of days="+d); 
}
}