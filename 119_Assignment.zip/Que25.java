import java.util.Scanner;
class Que25{
public static void main(String args[]){

Scanner s = new Scanner(System.in);
System.out.print("Enter no. of elements you want in array:");
int n = s.nextInt();

int arr[] = new int[n];

System.out.println("Enter array elements");
for(int i=0;i<arr.length;i++){
arr[i]=s.nextInt();
} 
for(int a:arr){ 
System.out.print(a+" ");
}
int sume=0;
int sumo=0;
for(int i=0;i<arr.length;i++){
if(arr[i]%2==0){
sume=sume+arr[i];
}else if(arr[i]%2==1){
sumo=sumo+arr[i];
}
}

System.out.println("\nsum of even= "+sume);

System.out.println("sum of odds= "+sumo);

}
}

