import java.util.Scanner;
class AssgnQue3{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the value of x and y ");
int x=sc.nextInt();
int y=sc.nextInt();


y=(x*x)+(3*x)-7;
System.out.println("y= "+y);

y=(x++ + ++x);
System.out.println("x= "+x);
System.out.println("y= "+y);

int z;
z=(x++ - --y - --x + x++);
System.out.println("x= "+x);
System.out.println("y= "+y);
System.out.println("z= "+z);


boolean c;
System.out.println("Enter values for a and b");
boolean a=sc.nextBoolean();
boolean b=sc.nextBoolean();

c=( a && b || !(a || b) );
System.out.println("c= "+c );
}
}